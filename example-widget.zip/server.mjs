// Generated MCP Apps example. Action handlers are explicit, harmless demo stubs.
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { registerAppResource, registerAppTool, RESOURCE_MIME_TYPE } from '@modelcontextprotocol/ext-apps/server';
import { z } from 'zod';

const config = {"name":"qa-native-final-v0-1-1","displayName":"QA Native final v0.1.1","tools":["echo_review"],"externalTools":[],"openTool":"open_widget","imageOrigins":[],"resourceUri":"ui://qa-native-final-v0-1-1/widget.html"};
const demoResult=(function makeDemoResult(name,args,forceError=false){
  const failed=forceError||args.__demoError===true||Object.values(args).includes('demo:error');
  return {...(failed?{isError:true}:{}),content:[{type:'text',text:failed?'Demo failure requested. Edit your input and try again.':'Demo '+name+' received '+JSON.stringify(args)+'.'}],structuredContent:{tool:name,arguments:args,demo:true}};
});
const html = readFileSync(new URL('./widget.html', import.meta.url), 'utf8');
export function createWidgetServer() {
  const server = new McpServer({ name: config.name, version: '1.0.0' });
  registerAppResource(server, 'widget', config.resourceUri, {}, async () => ({ contents: [{
    uri: config.resourceUri, mimeType: RESOURCE_MIME_TYPE, text: html,
    _meta: { ui: { prefersBorder: false, csp: { connectDomains: [], resourceDomains: config.imageOrigins } } },
  }] }));
  registerAppTool(server, config.openTool, {
    title: 'Open widget', description: 'Open the authored widget design. Use this to inspect this plugin UI.',
    inputSchema: {}, annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    _meta: { ui: { resourceUri: config.resourceUri, visibility: ['model', 'app'] } },
  }, async () => ({ content: [{ type: 'text', text: 'Opened ' + config.displayName + '. Local controls and navigation work immediately. See the integration handoff for tool setup.' }],
    structuredContent: { widgetName: config.displayName, demo: true } }));
  for (const name of config.tools) registerAppTool(server, name, {
    title: name, description: config.externalTools.includes(name)?'Setup placeholder. External integration is not connected.':'Synthetic demo handler. Echoes supplied JSON; performs no external action.',
    inputSchema: z.object({}).catchall(z.unknown()),
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
    _meta: { ui: { visibility: ['app'] } },
  }, async (args) => config.externalTools.includes(name)?{isError:true,content:[{type:'text',text:'External tool '+name+' is not connected. Use the integration handoff to ask your agent to connect it.'}],structuredContent:{tool:name,setupRequired:true,demo:false}}:demoResult(name,args));
  return server;
}

if (process.argv.includes('--stdio')) {
  await createWidgetServer().connect(new StdioServerTransport());
} else {
  const port = Number(process.env.PORT || 8787);
  const http = createServer(async (req, res) => {
    const path = new URL(req.url || '/', 'http://localhost').pathname;
    if (path === '/' && req.method === 'GET') { res.writeHead(200, { 'content-type': 'text/plain' }).end('Widget MCP Apps example'); return; }
    if (path !== '/mcp' || !['POST', 'GET', 'DELETE'].includes(req.method)) { res.writeHead(404).end('Not found'); return; }
    const server = createWidgetServer();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
    res.on('close', () => { void transport.close(); void server.close(); });
    try { await server.connect(transport); await transport.handleRequest(req, res); }
    catch (error) { console.error(error); if (!res.headersSent) res.writeHead(500).end('MCP request failed'); }
  });
  // Local example only. Use a secured HTTPS deployment for remote ChatGPT access.
  http.listen(port, '127.0.0.1', () => console.error('Widget MCP example: http://127.0.0.1:' + port + '/mcp'));
}
