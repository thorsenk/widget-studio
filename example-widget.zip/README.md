# Your widget

1. Unzip this bundle and open widget.html in a browser. Local fields, checkboxes, selections, tasks, validation, local submit and view navigation work immediately. Values stay in that open widget session. Tool buttons need a connected MCP Apps host.
2. Reopen project.widget.json in Widget Studio to keep editing. It contains all authored views and embedded images. The HTML includes the Start view and its connected/dependent views.
3. To connect real data or use it inside Codex/ChatGPT, give your agent this entire folder and AGENT-HANDOFF.md. The brief contains the current setup, missing decisions and exact verification work. You do not need to edit server code yourself.

## What is ready

Start: "Compose". Included views: 2. Local controls: 4; local/navigation actions: 3. See export-readiness.json for the exact inventory and issues.

No missing authored action/reference was detected. Test the complete intended journey before relying on it.

- echo_review: synthetic demo ready; echoes JSON and performs no external action.

## Agent setup reference

Use Node.js20 or later. Run npm install in this folder, then npm run start:stdio for a supported local MCP client, or npm start for http://127.0.0.1:8787/mcp. Call open_widget to read ui://qa-native-final-v0-1-1/widget.html. The portable plugin.json and mcp.json describe the local package. Do not install or activate it without the user authorizing that concrete step.

Synthetic demo handlers echo supplied JSON and perform no external action. For an error case use demo:error as a bound value or __demoError:true as a static argument. Tools marked external return an explicit setup error until their real handler is connected. The same tool name cannot have different demo/external handlers; external wins and the report flags mixed setup.

Exact one-key {$input:"node-id"} markers substitute current input/selection text; {$control:"node-id"} markers substitute typed widget values (checkbox booleans, list items or text). Markers may be nested; ordinary strings and objects with extra keys stay literal. Actions resolve values when clicked. Studio Preview simulates plugin tools; local actions and submission are real. Result mapping reads the selected structured field or readable response and optional success/error navigation.

## Host connection and evidence

The UI uses MCP Apps resources (text/html;profile=mcp-app), _meta.ui.resourceUri, ui/initialize, ui/notifications/initialized and tools/call over postMessage. Parent source and protocol version are checked. Host text is rendered as text. A standard MCP client may return tool text without rendering UI.

Exporting does not establish host compatibility: native rendering, installation, permissions, and connection in either host have not been tested by exporting it. For ChatGPT, an agent can prepare a secured HTTPS Streamable HTTP /mcp endpoint and the supported custom plugin connection; both deployment and connection require the user's authorization. Local stdio support varies by client. Verify Codex and ChatGPT independently using this exact final bundle.

Responsive layout, shared styles, local behavior, state overrides and reduced-motion-aware transitions use the same runtime as Studio Preview. Hidden layers are excluded; editor selection/locking tools are absent. Embedded raster images are already in the project/HTML; HTTPS images remain remote and depend on host CSP/network approval. No remote images are downloaded by export. Fonts use the same system stack as the canvas.

## Official documentation

- [OpenAI MCP server and UI quickstart](https://developers.openai.com/plugins/build/app-quickstart)
- [OpenAI UI integration](https://developers.openai.com/plugins/build/chatgpt-ui)
- [OpenAI plugin packaging and connection](https://developers.openai.com/plugins/build/plugins)

Host guidance checked2026-10-09 against official OpenAI documentation. Pinned package versions remain the checked example baseline; review updates before deployment. Export does not deploy, publish, install, register a connection or supply authentication.
